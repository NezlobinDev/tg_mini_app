from tortoise import fields, models


class User(models.Model):
    """ Модель пользователей """

    id = fields.IntField(unique=True)

    class Meta:
        table = 'users'

    def __str__(self):
        """ Строковое представление модели """
        return f'{self.id}'
