import json

from fastapi import APIRouter, Request
from starlette import status
from starlette.responses import Response

user_reg_auth_routers = APIRouter(prefix='/users', tags=['Users'])


@user_reg_auth_routers.get('/{user_id}/reg/')
async def registration(request: Request, user_id: int) -> Response:
    """ Создание Пользователя """

    return Response(
        content=json.dumps({'tg_u_id': user_id}),
        status_code=status.HTTP_200_OK,
        media_type='application/json',
    )
