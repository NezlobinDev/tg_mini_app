from tortoise import Tortoise

from aerich_init import TORTOISE_ORM
from config import MODELS


async def init_db():
    """ Инициализация базы данных """
    await Tortoise.init(
        config=TORTOISE_ORM,
        modules={'users': MODELS},
    )
    await Tortoise.generate_schemas()
