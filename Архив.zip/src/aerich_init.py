import os
import time

from config import DB_URL, MODELS, TIMEZONE

os.environ['TZ'] = TIMEZONE
time.tzset()

TORTOISE_ORM = {
    'connections': {
        'default': DB_URL,
    },
    'apps': {
        'users': {
            'models': MODELS + ['aerich.models'],
            'default_connection': 'default',
        },
    },
    'timezone': TIMEZONE,
}
