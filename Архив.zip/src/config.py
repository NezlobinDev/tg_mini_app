from utils.configured import config

DEBUG = bool(config('DEBUG', default=False))

api_version = 'v1'

DB_URL = config('DB_URL','sqlite://db.sqlite3')
TIMEZONE = config('TIMEZONE', 'Europe/Moscow')
TG_WEP_APP_TOKEN = ''


MODELS = ['users.models']
