from dataclasses import dataclass
from enum import Enum
from typing import Any


class ErrorLevel(Enum):
    """ Уровень ошибок. В случае CRITICAL требуется отмена заявки. """

    CRITICAL = 0
    ERROR = 1


@dataclass
class Error:
    """ Класс ошибки """

    error_level: ErrorLevel
    message: dict[str, Any]
    function_name: str
    source: str = 'bms'

    def to_dict(self) -> dict[str, Any]:
        """ Возвращает словарь для формирования сообщения об ошибке """
        return {
            'error_level': self.error_level.value,
            'message': self.message,
            'function_name': self.function_name,
            'source': 'bms',
        }
