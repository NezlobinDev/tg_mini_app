import json

from starlette import status
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response


class ErrorMiddleware(BaseHTTPMiddleware):
    """ Errors handling """

    async def dispatch(self, request, call_next):
        """ Perform """
        try:
            response = await call_next(request)
        except Exception as e:
            return Response(
                content=json.dumps(
                    {
                        'error': {
                            'type': 'Ошибка запроса.',
                            'summary': str(e),
                        },
                    },
                ),
                status_code=status.HTTP_400_BAD_REQUEST,
                media_type='application/json',
            )
        return response
