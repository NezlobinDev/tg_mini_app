import json

JSON_ENV_PATH = 'env.json'


def config(name='', default=None):
    """ Конфигурации сервиса """
    result = {}
    try:  # noqa: SIM105
        with open(JSON_ENV_PATH, 'r') as f:
            result = json.loads(f.read())
    except FileNotFoundError:
        pass
    return result.get(name, default)
