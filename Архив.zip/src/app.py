from fastapi import FastAPI
from tortoise.contrib.fastapi import register_tortoise

from aerich_init import TORTOISE_ORM
from users.api import user_reg_auth_routers
from config import api_version
from db_init import MODELS
from middlewares import ErrorMiddleware

app = FastAPI()

urlpatterns = [
    (user_reg_auth_routers, f'/api/{api_version}'),
]

for pattern in urlpatterns:
    app.include_router(pattern[0], prefix=pattern[1])

register_tortoise(
    app,
    modules={'users': MODELS},
    generate_schemas=True,
    add_exception_handlers=True,
    config=TORTOISE_ORM,
)

app.add_middleware(ErrorMiddleware)
